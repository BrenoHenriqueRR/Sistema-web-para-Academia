document.getElementById('open_btn').addEventListener('click', function(){
    document.getElementById('menu-lat').classList.toggle('open-menu');
    document.getElementById('overlay').classList.toggle('active');
    document.getElementById('body').classList.toggle('no-scroll');
})
document.getElementById('open_btn2').addEventListener('click', function(){
    document.getElementById('menu-lat').classList.toggle('open-menu');
    document.getElementById('overlay').classList.toggle('active');
    document.getElementById('body').classList.toggle('no-scroll');
})
